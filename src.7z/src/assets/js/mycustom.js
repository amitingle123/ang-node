
 function myTest() {
    alert('Welcome to custom js');
    console.log("----------");
}

// $(function() {
//     alert('Hello, custom js');
// });
